<template>
    <div class="">
        <img src="../../assets/jumpborwser.png" alt="" style="width:100%">
    </div>
</template>

<script>
export default {
    data() {
        return {
            
        }
    }
}
</script>

<style lang="stylus" scoped>

</style>
