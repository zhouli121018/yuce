/*
  eventBus 不需要vuex的使用eventbus 转发事件
*/
import Vue from 'vue'
export default new Vue()

